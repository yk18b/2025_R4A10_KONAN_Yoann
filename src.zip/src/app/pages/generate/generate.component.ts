import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DESTINATIONS, PRIX, DESCRIPTIONS } from '../../data';

@Component({
  selector: 'app-generate',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './generate.component.html',
  styleUrl: './generate.component.scss'
})
export class GenerateComponent {
  voyagesAleatoires: { destination: string; description: string; prix: number }[] = [];

  constructor() {}

  genererVoyage() {
    const index = Math.floor(Math.random() * DESTINATIONS.length); // Choisir un index aléatoire
    const voyage = {
      destination: DESTINATIONS[index],
      description: DESCRIPTIONS[index],
      prix: PRIX[index]
    };

    this.voyagesAleatoires.push(voyage);
  }

  supprimerVoyage(voyage: { destination: string; description: string; prix: number }) {
    this.voyagesAleatoires = this.voyagesAleatoires.filter(v => v !== voyage);
  }


}
