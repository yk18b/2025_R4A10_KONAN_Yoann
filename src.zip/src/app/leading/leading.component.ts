import { Component } from '@angular/core';

@Component({
  selector: 'app-leading',
  imports: [],
  templateUrl: './leading.component.html',
  styleUrl: './leading.component.scss'
})
export class LeadingComponent {

}
