require('./test_array')
require('./test_string');
require('./test_object');
require('./test_combine');
require('./test_controle')