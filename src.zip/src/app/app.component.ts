import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { ServicesComponent } from './services/services.component';

import{LeadingComponent} from './leading/leading.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';

@Component({
  selector: 'app-root',
  imports: [ HeaderComponent,ServicesComponent,LeadingComponent,TestimonialsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  standalone: true
})
export class AppComponent {
  title = 'Yoan tp2';
  private readonly title2 = 'test';


}
