/*
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DESTINATIONS, PRIX, DESCRIPTIONS } from '../../data';

@Component({
  selector: 'app-voyage-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './voyage-detail.component.html',
  styleUrl: './voyage-detail.component.scss'
})
export class VoyageDetailComponent {
  voyage: { destination: string; description: string; prix: number } | undefined;

  constructor(private route: ActivatedRoute) {
    const id = Number(this.route.snapshot.paramMap.get('id')); // Récupère l'index depuis l'URL

    if (id >= 0 && id < DESTINATIONS.length) {
      this.voyage = {
        destination: DESTINATIONS[id],
        description: DESCRIPTIONS[id],
        prix: PRIX[id]
      };
    }
  }
}
*/ 
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DESTINATIONS, PRIX, DESCRIPTIONS } from '../../data';

@Component({
  selector: 'app-voyage-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './voyage-detail.component.html',
  styleUrls: ['./voyage-detail.component.scss']
})
export class VoyageDetailComponent {
  voyage: { destination: string; description: string; prix: number } | undefined;

  constructor(private route: ActivatedRoute) {
    const id = Number(this.route.snapshot.paramMap.get('id')); // Récupère l'index depuis l'URL

    if (id >= 0 && id < DESTINATIONS.length) {
      this.voyage = {
        destination: DESTINATIONS[id],
        description: DESCRIPTIONS[id],
        prix: PRIX[id]
      };
    }
  }
}
