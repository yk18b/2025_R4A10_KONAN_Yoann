import { Component } from '@angular/core';
import { DESTINATIONS,PRIX,DESCRIPTIONS } from '../../data'; 
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router'; 

@Component({
  selector: 'app-card',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './card.component.html',
  styleUrl: './card.component.scss',
  
})
export class CardComponent {
   voyages : {destination:string,description:string,prix:number} [] = [];
    
    constructor(){
      for (let i = 0 ; i < DESTINATIONS.length ; i++ ){
  
        this.voyages.push(
           {
            destination : DESTINATIONS[i],
            description:DESCRIPTIONS[i],
            prix:PRIX[i] 
           }
        )
    
        
      }
  
    }
    supprimerVoyage(index: number) {
      this.voyages = this.voyages.filter((_, i) => i !== index);
    }
    


}
