import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  standalone: true
})
export class AppComponent {
  title = 'Yoan tp2';
  private readonly title2 = 'test';


  /*
  type mc = {
    titre = string;
    tag =
   
  } 
    */

}
