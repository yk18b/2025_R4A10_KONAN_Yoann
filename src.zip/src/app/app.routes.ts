import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { VoyageDetailComponent } from './pages/voyage-detail/voyage-detail.component';
import { GenerateComponent } from './pages/generate/generate.component';

export const routes: Routes = [
    {path:'', redirectTo:'home', pathMatch:'full'},
    {path:'home',component: HomeComponent},
    {path:'voyageDetail/:id', component:VoyageDetailComponent},
    {path:'generate', component:GenerateComponent},

];
