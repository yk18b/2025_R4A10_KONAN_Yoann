import { Component, inject, Output } from '@angular/core';
import { BooksInMemoryService } from '../../services/book-inmemory.service';
import { Book } from '../../models/book';
import { NgIf, NgFor } from '@angular/common'
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import { LivreAPIService } from '../../services/livre-api-service';
import {take, tap} from "rxjs";

@Component({
  selector: 'app-create-book-page',
  standalone: true,
  imports: [ReactiveFormsModule ],
  templateUrl: './create-book-page.component.html',
  styleUrl: './create-book-page.component.css',
})
export class CreateBookPageComponent {
@Output() bookCreated = new EventEmitter<number>();

livreformulaire: FormGroup;

constructor(/*private booksInMemoryService: BooksInMemoryService*/  private livreApiService: LivreAPIService, private formulaire: FormBuilder, private route: Router) {
  this.livreformulaire = this.formulaire.group({
    author:['', [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],


    title:['', [Validators.required, Validators.minLength(5), Validators.maxLength(35)]],

    description:['', [Validators.required, Validators.minLength(15), Validators.maxLength(255)]]
  });
}

/*
test quui n'a pas fonctionné
  addBook() {
    if (this.newBook.title?.trim() && this.newBook.author?.trim()) {
      this.bookService.createBook({
        title: this.newBook.title,
        author: this.newBook.author,
        description: this.newBook.description || '',
      });
      this.books = this.bookService.getAllBooks(); 
      this.newBook = { title: '', author: '', description: '' };
    }
  }
*/
onSubmit(): void {
  if (this.livreformulaire.valid) {
    this.livreApiService.createBook(this.livreformulaire.value).pipe(take(1)).subscribe(createdBook => {
      this.bookCreated.emit(createdBook.id);
      this.livreformulaire.reset();
    });
  }
}
}
