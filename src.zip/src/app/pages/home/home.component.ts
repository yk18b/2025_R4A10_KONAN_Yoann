import { Component } from '@angular/core';
import { CardComponent } from '../../components/card/card.component';

@Component({
  selector: 'app-home',
  imports: [CardComponent],
  templateUrl: './home.component.html',
  standalone: true, 
  styleUrl: './home.component.scss'
})
export class HomeComponent {

}
