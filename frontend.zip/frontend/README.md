# Installation

Lancez la commande `npm i`

# Lancement

Lancez la commande `ng serve` ou `npm run start` au choix
